<?php
/**
 * Theme functions and definitions
 *
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

// if ( ! isset( $content_width ) ) {
// 	$content_width = 800; // pixels
// }

/*
 * Set up theme support
 */
if ( ! function_exists( 'hello_elementor_theme_setup' ) ) {
	function hello_elementor_theme_setup() {
		if ( apply_filters( 'hello_elementor_theme_load_textdomain', true ) ) {
			load_theme_textdomain( 'elementor-hello-theme', get_template_directory() . '/languages' );
		}

		if ( apply_filters( 'hello_elementor_theme_register_menus', true ) ) {
			register_nav_menus( array( 'menu-1' => __( 'Primary', 'hello-elementor' ) ) );
		}

		if ( apply_filters( 'hello_elementor_theme_add_theme_support', true ) ) {
			add_theme_support( 'post-thumbnails' );
			add_theme_support( 'automatic-feed-links' );
			add_theme_support( 'title-tag' );
			add_theme_support( 'custom-logo' );
			add_theme_support( 'html5', array(
				'search-form',
				'comment-form',
				'comment-list',
				'gallery',
				'caption',
			) );
			add_theme_support( 'custom-logo', array(
				'height' => 100,
				'width' => 350,
				'flex-height' => true,
				'flex-width' => true,
			) );

			/*
			 * Editor Style
			 */
			add_editor_style( 'editor-style.css' );

			/*
			 * WooCommerce
			 */
			if ( apply_filters( 'hello_elementor_theme_add_woocommerce_support', true ) ) {
				// WooCommerce in general:
				add_theme_support( 'woocommerce' );
				// Enabling WooCommerce product gallery features (are off by default since WC 3.0.0):
				// zoom:
				add_theme_support( 'wc-product-gallery-zoom' );
				// lightbox:
				add_theme_support( 'wc-product-gallery-lightbox' );
				// swipe:
				add_theme_support( 'wc-product-gallery-slider' );
			}
		}
	}
}
add_action( 'after_setup_theme', 'hello_elementor_theme_setup' );

/*
 * Theme Scripts & Styles
 */
if ( ! function_exists( 'hello_elementor_theme_scripts_styles' ) ) {
	function hello_elementor_theme_scripts_styles() {
		if ( apply_filters( 'hello_elementor_theme_enqueue_style', true ) ) {
			wp_enqueue_style( 'elementor-hello-theme-style', get_stylesheet_uri() );
		}
	}
}
add_action( 'wp_enqueue_scripts', 'hello_elementor_theme_scripts_styles' );

/*
 * Register Elementor Locations
 */
if ( ! function_exists( 'hello_elementor_theme_register_elementor_locations' ) ) {
	function hello_elementor_theme_register_elementor_locations( $elementor_theme_manager ) {
		if ( apply_filters( 'hello_elementor_theme_register_elementor_locations', true ) ) {
			$elementor_theme_manager->register_all_core_location();
		}
	}
}
add_action( 'elementor/theme/register_locations', 'hello_elementor_theme_register_elementor_locations' );


add_action('pre_get_posts','custom_query_vars');
function custom_query_vars($query) {
	$query->set('current_date', date('Y-m-d'));
	return $query;
}


/* ALLOW SVG UPLOAD */
function enable_svg_upload( $upload_mimes ) {	
    $upload_mimes['svg'] = 'image/svg+xml';
    $upload_mimes['svgz'] = 'image/svg+xml';

    return $upload_mimes;
}


add_filter( 'upload_mimes', 'enable_svg_upload', 10, 1 );


/* DISABLE GUTTENBURG */
add_filter('use_block_editor_for_post', '__return_false', 10);


/* DISABLE WP AUTOMATIC IMAGE SCALE */
add_filter( 'big_image_size_threshold', '__return_false' );


/* ADD SEARCH RESULT COUNT */
function result_count() {
	add_filter( 'wpex_post_subheading', function( $subheading ) {
		if ( is_search() ) {
			global $wp_query;
			$posts_per_page = $wp_query->query_vars['posts_per_page'];
			$posts_found    = $wp_query->found_posts;
			if ( $posts_found ) {
				$subheading = sprintf(
					esc_html__( 'Displaying results 1-%1$s out of %2$s for %3$s', 'total' ),
					$posts_per_page,
					$posts_found,
					get_search_query( false )
				);
			}
		}
		return $subheading;
		var_dump($subheading);
	} );
}
// add_shortcode('result_count','result_count');

// function control_search_results($subheading) {
//     if ( is_search() ) {
// 		global $wp_query;
// 		$posts_per_page = $wp_query->query_vars['posts_per_page'];
// 		$posts_found    = $wp_query->found_posts;
// 		if ( $posts_found ) {
// 			$subheading = sprintf(
// 				esc_html__( 'Displaying results 1-%1$s out of %2$s for %3$s', 'total' ),
// 				$posts_per_page,
// 				$posts_found,
// 				get_search_query( false )
// 			);
// 		}
// 	}
	
// 	return $subheading;
        
// }
// add_filter('pre_get_posts', 'control_search_results');